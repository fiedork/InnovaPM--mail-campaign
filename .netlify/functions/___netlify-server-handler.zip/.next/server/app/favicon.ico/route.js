var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_1081pat._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_12f2k_b.js")
R.c("server/chunks/node_modules_next_08s853w._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/_next-internal_server_app_favicon_ico_route_actions_0g2jjls.js")
R.m(27413)
module.exports=R.m(27413).exports
